---
name: Cyber-Tropical Energy System
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#ffffff'
  on-secondary: '#283500'
  secondary-container: '#c3f400'
  on-secondary-container: '#556d00'
  tertiary: '#fff3f0'
  on-tertiary: '#5a1b00'
  tertiary-container: '#ffcfbe'
  on-tertiary-container: '#a83a00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#c3f400'
  secondary-fixed-dim: '#abd600'
  on-secondary-fixed: '#161e00'
  on-secondary-fixed-variant: '#3c4d00'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#802a00'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: sora
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: jetbrainsMono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: jetbrainsMono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system embodies a "Cyber-Tropical" aesthetic—a high-energy intersection between Shinjuku’s precision-engineered neon and the lush, rhythmic vitality of a Rio de Janeiro summer. It targets a Gen-Z and Millennial demographic interested in sustainability, gamified finance, and green tech. 

The visual style is **Neon-Minimalist**. It utilizes deep charcoal backgrounds to allow vibrant electric hues to "pulse" off the screen. It avoids traditional clunky "eco-friendly" tropes (soft greens and browns) in favor of high-octane performance visuals that treat energy conservation as an elite, futuristic sport. The atmosphere is optimistic, fast-paced, and digitally organic.

## Colors
This design system uses a high-contrast dark mode foundation to maximize the "glow" effect of its functional colors.

- **Electric Blue (Primary):** Represents the piezoelectric spark and core technology. Used for primary actions and active states.
- **Lime Green (Secondary):** Represents growth, energy generation, and Brazilian vitality. Used for success states and progress indicators.
- **Sunset Orange (Tertiary):** Represents heat, movement, and human effort. Used for highlights, rewards, and "burning" energy levels.
- **Deep Charcoal & Black (Neutrals):** Provides a stable, professional backdrop that grounds the vibrant accents.

Gradients are used sparingly but effectively, typically transitioning from Primary Blue to Secondary Green to signify energy conversion.

## Typography
The typography strategy balances technical precision with modern accessibility.

- **Headlines:** We use **Sora** for its geometric, futuristic construction and wide stance. It feels "engineered" yet premium.
- **Body:** **Inter** provides maximum legibility for dense data, ensuring the gamified stats remain readable even during fast-paced interactions.
- **Data/Labels:** **JetBrains Mono** is used for all numerical data, energy readings, and technical labels to evoke a "hacker-ready" developer interface aesthetic.

Scale: Headlines should use tight tracking and heavy weights. Labels should use slight wide-tracking and uppercase styles to maintain a structural, architectural feel.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a hard 8px rhythmic baseline. 

- **Desktop:** 12-column grid with 40px outer margins. Content blocks are often asymmetrical to create a sense of movement.
- **Mobile:** 4-column grid with 16px outer margins. Elements use vertical stacking with tight gutters (12px) to maintain a dense, "packed" energetic feel.

Spacing is used to create "zones" of energy. High-activity areas (game boards, stats) use tight spacing (`sm` and `xs`), while narrative or brand-heavy sections use large expansive whitespace (`xl`) to allow the neon accents to breathe.

## Elevation & Depth
Elevation in this system is conveyed through **Light Emission** rather than traditional shadows.

- **Backdrop Blurs:** Surfaces use a 20px blur with a 10% opacity white or primary-color tint to create a "glass tech" feel.
- **Inner Glows:** Instead of drop shadows, active cards use a subtle 1px inner border in the primary color to suggest the component is powered on.
- **Neon Bloom:** High-priority elements (like the "Claim Energy" button) use an outer glow (`drop-shadow`) with a spread of 15px and a 30% opacity of the primary color.
- **Z-Axis:** Lower tiers are flat and dark; as elements rise in hierarchy, they gain more transparency and stronger glow intensity.

## Shapes
The shape language is **Soft-Tech**. 

We avoid full-round pills to maintain a sense of structural engineering, favoring a 4px-8px radius for most containers. This provides a balance between the organic "tropical" flow and the "cyber" rigidity. 

**Interactive Elements:** Use a consistent 4px (Soft) radius.
**Large Containers:** Use an 8px radius.
**Decorative Trims:** Use 45-degree "clipped corners" on specific energy cards to reference Japanese industrial design and Brazilian architectural brutalism.

## Components
- **Buttons:** Primary buttons use a solid Electric Blue fill with black text. On hover, they emit a "bloom" glow. Secondary buttons use a ghost style with a Lime Green 1px stroke.
- **Energy Chips:** Small, monospaced labels used for categorization. They feature a left-side 2px solid bar in a status color (Blue for Active, Orange for High Demand).
- **Cards:** Glassmorphic surfaces with a 1px top-left highlight and a subtle 45-degree tropical leaf pattern watermark in the background (5% opacity).
- **Input Fields:** Bottom-border only by default, turning into a full glowing Electric Blue box when focused.
- **Progress Bars:** Dual-layered. A dark charcoal track with a glowing gradient (Blue to Green) fill that features a subtle "pulse" animation moving from left to right.
- **Iconography:** Linear, 2px stroke weight. Icons should mix Japanese minimalism (clean, geometric) with tropical motifs (simplified Monstera leaves, sunbursts, wave patterns).